<?php 
/**
*	
*	Distribution of homosexuals in Berlin
*	
**/

include "../../php/modules.php";

$article 	= 'Distribution of homosexuals in Berlin';
$language	= 'de';
$cn			= get_ffs_conn();
?>

<!DOCTYPE html PUBLIC>
<html>
<head>

<!-- Stylesheet Import -->
<link href="../../favicon.ico" 						rel="shortcut icon">
<link href="../../css/fenixfox-theme.css" 			rel="stylesheet" />
<link href="../../css/article-theme.css" 			rel="stylesheet" />
<link href="../../plugins/teamspeak-theme.css" 		rel="stylesheet" />
<link href="../../css/news-theme.css" 				rel="stylesheet" />
<link href="../../plugins/prism.css" 				rel="stylesheet" />


<!-- Fonts -->
<link href="//fonts.googleapis.com/css?family=Merriweather:300,700,700italic,300italic|Open+Sans:700,400" rel="stylesheet"/>

<!-- MetaData for SearchEngine Optimization -->
<?php echo get_ffs_meta($cn, $article, $language) ?>

<title><?php echo $article; ?></title>
</head>

<body>
<?php echo get_ffs_analytics(); ?>
<script src="../../plugins/prism.js"></script>

<header id="header">
	<nav>
		<div class="header-top" style="display:none;"><?php echo get_ffs_header($cn, $language); ?></div>
		<div class="header-bot"><?php echo get_ffs_tags($cn, $language); ?></div>
	</nav>
</header>

<div id="main">
<?php echo get_ffs_article($cn, $article , $language); ?>
<!--
<div class="inner-layout">

<div id="article">
<article>
</article>
</div>

<div id="news">
<div class="news-header">
Latest News
</div>
<div class="news-items"><?php echo get_ffs_news($cn,7); ?></div>
</div>
</div>
-->
</div>
</body>
</html>
