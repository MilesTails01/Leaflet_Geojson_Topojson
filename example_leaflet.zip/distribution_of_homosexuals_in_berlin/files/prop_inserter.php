<!DOCTYPE html PUBLIC>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>leaflet demo</title>
</head>
<body>
<?php
$file 		= fopen("json/mieten-data.topo.json", "r") or die("Unable to open file!");
$topo_data 	= fread($file,filesize("json/mieten-data.topo.json"));

$file 		= fopen("amount1414.txt", "r") or die("Unable to open file!");
$dbna_data	= fread($file,filesize("amount1414.txt"));

fclose($file);

$gay_amount_array = explode("\n", $dbna_data);

$counter 	= 0;

//while(strpos($topo_data, "gay1428") == true)
for($i = 0; $i<190; $i++)
{	
	$caret_left 	= strpos($topo_data, "gay1428") - 2;
//	$caret_right 	= strpos($topo_data, "}", $caret_left);
//	$length 		= $caret_right - $caret_left;
	
	$topo_data 		= substr_replace($topo_data, ',"gay1427":"' . trim($gay_amount_array[$counter]) . '"', $caret_left,0);
	$counter++;
}

echo $topo_data;
*/
?> 

</body>
</html>