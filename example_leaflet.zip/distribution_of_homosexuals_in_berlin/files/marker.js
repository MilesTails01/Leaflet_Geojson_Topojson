var markers = {
"type": "FeatureCollection",
                                                                                
"features": [
{ "type": "Feature", "properties": { "name":"Tegel", "lat":"52.58594625844847", "lng":"13.289337158203123", "scalerank":"1" } },
{ "type": "Feature", "properties": { "name":"Pankow", "lat":"52.58636344214016", "lng":"13.448638916015625", "scalerank":"1" } },
{ "type": "Feature", "properties": { "name":"Marzahn", "lat":"52.55548112214005", "lng":"13.560562133789062", "scalerank":"1" } },
{ "type": "Feature", "properties": { "name":"Spandau", "lat":"52.532513955470336", "lng":"13.175354003906248", "scalerank":"1" } },
{ "type": "Feature", "properties": { "name":"Mitte", "lat":"52.52958999943302", "lng":"13.387527465820312", "scalerank":"1" } },
{ "type": "Feature", "properties": { "name":"Friedrichshain", "lat":"52.51413156895822", "lng":"13.472671508789062", "scalerank":"1" } },
{ "type": "Feature", "properties": { "name":"Kreuzberg", "lat":"52.495741489296144", "lng":"13.401947021484375", "scalerank":"1" } },
{ "type": "Feature", "properties": { "name":"Grunewald", "lat":"52.474834331541906", "lng":"13.261871337890625", "scalerank":"1" } },
{ "type": "Feature", "properties": { "name":"K&ouml;pernick", "lat":"52.449732623925755", "lng":"13.5626220703125", "scalerank":"1" } },
{ "type": "Feature", "properties": { "name":"Wannsee", "lat":"52.41875413722616", "lng":"13.17329406738281", "scalerank":"1" } },
{ "type": "Feature", "properties": { "name":"Frohnau", "lat":"52.63222940855761", "lng":"13.296890258789062", "scalerank":"2" } },
{ "type": "Feature", "properties": { "name":"Prenzlauer Berg", "lat":"52.540449426243796", "lng":"13.451385498046875", "scalerank":"2" } },
{ "type": "Feature", "properties": { "name":"Charlottenburg", "lat":"52.518727886767266", "lng":"13.322296142578125", "scalerank":"2" } },
{ "type": "Feature", "properties": { "name":"Kaulsdorf", "lat":"52.50368360390624", "lng":"13.589401245117186", "scalerank":"2" } },
{ "type": "Feature", "properties": { "name":"Neuk&ouml;lln", "lat":"52.482780222078205", "lng":"13.442459106445312", "scalerank":"2" } },
{ "type": "Feature", "properties": { "name":"Zehlendorf", "lat":"52.43005962183452", "lng":"13.26393127441406", "scalerank":"2" } },
{ "type": "Feature", "properties": { "name":"Rahnsdorf", "lat":"52.43968793313462", "lng":"13.7109375", "scalerank":"2" } },
{ "type": "Feature", "properties": { "name":"Heiligensee", "lat":"52.60971939156648", "lng":"13.253631591796875", "scalerank":"3" } },
{ "type": "Feature", "properties": { "name":"Wedding", "lat":"52.54504299065421", "lng":"13.3648681640625", "scalerank":"3" } },
{ "type": "Feature", "properties": { "name":"Lichtenberg", "lat":"52.50159371284437", "lng":"13.515243530273438", "scalerank":"3" } },
{ "type": "Feature", "properties": { "name":"Sch&ouml;neberg", "lat":"52.483616548133604", "lng":"13.354911804199219", "scalerank":"3" } },
{ "type": "Feature", "properties": { "name":"Obersch&ouml;neweide", "lat":"52.46040259846574", "lng":"13.526573181152344", "scalerank":"3"} },
{ "type": "Feature", "properties": { "name":"Steglitz", "lat":"52.45475411046546", "lng":"13.343582153320312", "scalerank":"3"} }
] };	
	

























	