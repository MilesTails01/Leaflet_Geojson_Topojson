<!DOCTYPE html PUBLIC>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>leaflet demo</title>
</head>
<body>
<?php
$file 		= fopen("mieten-data.topo.json", "r") or die("Unable to open file!");
$topo_data 	= fread($file,filesize("mieten-data.topo.json"));

$file 		= fopen("amount1428.txt", "r") or die("Unable to open file!");
$data1428	= fread($file,filesize("amount1428.txt"));

$file 		= fopen("amount1427.txt", "r") or die("Unable to open file!");
$data1427	= fread($file,filesize("amount1427.txt"));

$file 		= fopen("amount1426.txt", "r") or die("Unable to open file!");
$data1426	= fread($file,filesize("amount1426.txt"));

$file 		= fopen("amount1425.txt", "r") or die("Unable to open file!");
$data1425	= fread($file,filesize("amount1425.txt"));

$file 		= fopen("amount1424.txt", "r") or die("Unable to open file!");
$data1424	= fread($file,filesize("amount1424.txt"));

$file 		= fopen("amount1423.txt", "r") or die("Unable to open file!");
$data1423	= fread($file,filesize("amount1423.txt"));

$file 		= fopen("amount1422.txt", "r") or die("Unable to open file!");
$data1422	= fread($file,filesize("amount1422.txt"));

$file 		= fopen("amount1421.txt", "r") or die("Unable to open file!");
$data1421	= fread($file,filesize("amount1421.txt"));

$file 		= fopen("amount1420.txt", "r") or die("Unable to open file!");
$data1420	= fread($file,filesize("amount1420.txt"));

$file 		= fopen("amount1419.txt", "r") or die("Unable to open file!");
$data1419	= fread($file,filesize("amount1419.txt"));

$file 		= fopen("amount1418.txt", "r") or die("Unable to open file!");
$data1418	= fread($file,filesize("amount1418.txt"));

$file 		= fopen("amount1417.txt", "r") or die("Unable to open file!");
$data1417	= fread($file,filesize("amount1417.txt"));

$file 		= fopen("amount1416.txt", "r") or die("Unable to open file!");
$data1416	= fread($file,filesize("amount1416.txt"));

$file 		= fopen("amount1415.txt", "r") or die("Unable to open file!");
$data1415	= fread($file,filesize("amount1415.txt"));

$file 		= fopen("amount1414.txt", "r") or die("Unable to open file!");
$data1414	= fread($file,filesize("amount1414.txt"));

fclose($file);

$amountArray1428 = explode("\n", $data1428);
$amountArray1427 = explode("\n", $data1427);
$amountArray1426 = explode("\n", $data1426);
$amountArray1425 = explode("\n", $data1425);
$amountArray1424 = explode("\n", $data1424);
$amountArray1423 = explode("\n", $data1423);
$amountArray1422 = explode("\n", $data1422);
$amountArray1421 = explode("\n", $data1421);
$amountArray1420 = explode("\n", $data1420);
$amountArray1419 = explode("\n", $data1419);
$amountArray1418 = explode("\n", $data1418);
$amountArray1417 = explode("\n", $data1417);
$amountArray1416 = explode("\n", $data1416);
$amountArray1415 = explode("\n", $data1415);
$amountArray1414 = explode("\n", $data1414);

$counter 	= 0;

while(strpos($topo_data, "15_kalt_qm") == true)
{	
	$caret_left 	= strpos($topo_data, "15_kalt_qm") - 2;
	$caret_right 	= strpos($topo_data, "}", $caret_left);
	$length 		= $caret_right - $caret_left;
	
	$topo_data 		= substr_replace($topo_data, 	',"gay1428":"' . trim($amountArray1428[$counter]) . '"' . 
													',"gay1427":"' . trim($amountArray1427[$counter]) . '"' .
													',"gay1426":"' . trim($amountArray1426[$counter]) . '"' .
													',"gay1425":"' . trim($amountArray1425[$counter]) . '"' .
													',"gay1424":"' . trim($amountArray1424[$counter]) . '"' .
													',"gay1423":"' . trim($amountArray1423[$counter]) . '"' .
													',"gay1422":"' . trim($amountArray1422[$counter]) . '"' .
													',"gay1421":"' . trim($amountArray1421[$counter]) . '"' .
													',"gay1420":"' . trim($amountArray1420[$counter]) . '"' .
													',"gay1419":"' . trim($amountArray1419[$counter]) . '"' .
													',"gay1418":"' . trim($amountArray1418[$counter]) . '"' .
													',"gay1417":"' . trim($amountArray1417[$counter]) . '"' .
													',"gay1416":"' . trim($amountArray1416[$counter]) . '"' .
													',"gay1415":"' . trim($amountArray1415[$counter]) . '"' .
													',"gay1414":"' . trim($amountArray1414[$counter]) . '"' , $caret_left, $length);
	$counter++;
}

echo $topo_data;

?> 

</body>
</html>