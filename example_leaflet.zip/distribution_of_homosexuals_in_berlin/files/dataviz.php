<!DOCTYPE html PUBLIC>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>leaflet demo</title>
<link rel="stylesheet" href="http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.css" />
<link href='https://fonts.googleapis.com/css?family=Lato:300,400,700,900' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="slider.css">
<link rel="stylesheet" href="markers.css">
<style type="text/css">
	html, body, #map {
/*		height:600px;
		width:900px;*/
		height:100%;
		width:100%;
		margin:0px;
		padding:0px;
		color:#222;
		overflow:hidden;
		font-size:1em;
		line-height:1.4;
	}
	
	#map {
		background:#f4f4f4;
		color:#222;
	}
		
	.legend {
		
		width:225px;
		top:20px;
		right:20px;
		bottom:auto;
		padding:20px;
		
		font-family: 'Lato';
		font-weight: 400;
		font-size:13px;
		line-height:1.1;

		background: rgba(246,246,246,0.8);
		color:#222;
		border-style:solid;
		border-width:1px;
		border-color:#ddd;
		box-shadow: 0 0 15px rgba(0,0,0,0.025);
		/*	border-radius: 5px; */
	}
	
	.legend-label {
		font-family: 'Lato', sans-serif;
		font-weight: 400;
		font-size: 13px;
		line-height: 1.3;
	}
	
	.legend i {
	
		width: 18px;
		height: 18px;
		float:left;
		margin-right: 8px;
		opacity: 0.7;
		box-shadow: 0 0 7px rgba(0,0,0,0.1);
	}
	
	.legend-title {
		font-family: 'Lato';
		font-weight: bold;
		font-size:14px;
		line-height:1.5;
		color:#222;
	}
	
	.settings {
		
		width:280px;
		top:20px;
		left:20px;
		bottom:auto;
		padding:20px;
		
		font-family: 'Lato';
		font-weight: 400;
		font-size:14px;
		line-height:1.3;

		background: rgba(250,250,250,0.8);
		color:#555;
		box-shadow: 0 0 15px rgba(0,0,0,0.025);
		border-radius: 10px;
	}
	
	.settings-title {
		font-family: 'Lato';
		font-weight: bold;
		font-size:17px;
		line-height:1.3;
		color:#222;
	}
	
	.infobox {
		pointer-events: none;
		background-color:#ffffff;
		width:280px;
		/*z-index:99;*/
		position:absolute;
		display:none;
				
		width:280px;
		height:auto;
		bottom:auto;
		top:-1000px;

		padding:20px;
		
		font-family: 'Lato';
		font-weight: 400;
		font-size:13px;
		line-height:1.3;

		background: rgba(250,250,250,0.9);
		color:#777;
		box-shadow: 0 0 15px rgba(0,0,0,0.025);
		border-left:solid 5px; 
		border-left-color:#006633;
	}
	
</style>

</head>

<body>

<!-- Chromajs Script to calculate the most similar color inside a range -->
<script src="//cdnjs.cloudflare.com/ajax/libs/chroma-js/0.5.9/chroma.min.js"></script>

<!-- TopoJson to GeoJSON converter to feed leaflet with the converted data-->
<script src="http://d3js.org/topojson.v1.min.js"></script>  

<!-- Leaflet Include file-->
<script src="http://cdn.leafletjs.com/leaflet/v0.7.7/leaflet.js"></script>

<!-- JQueryLibrary to load topodata inside the topolayer-->
<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>  

<!-- ClusterPlugin needed for the Collision plugin-->
<script src="plugins/rbush.js"></script>

<!-- CollisionPlugin used for a scaleranked simplification-->
<script src="plugins/Leaflet.LayerGroup.Collision.js"></script>

<!-- Citymarker GeoJSOn formatted data-->
<script src="marker.js"></script>


<script>
/*
*	Extension for Leaflet to use TopoJSON
*	Snippet by (c) 2013 Ryan Clark
*	https://gist.github.com/rclark/5779673
*/
	L.TopoJSON = L.GeoJSON.extend(
	{
		addData: function(jsonData) 
		{    
			if (jsonData.type === "Topology") 
			{
				for (key in jsonData.objects) 
				{
					geojson = topojson.feature(	jsonData, 
												jsonData.objects[key]);
					L.GeoJSON.prototype.addData.call(this, geojson);
				}
			}    
			else 
			{
				L.GeoJSON.prototype.addData.call(this, jsonData);
			}
		}  
	});
</script>

<div id="map"></div>
<script>
	/**
	* @func		map:						initialize the leaflet widget L*
	* @param	$div			STRING		elementname of the div where the widget shows up
	* @param	$settings		JSON[]		options to configure leaflet widget
	* @param	$layer			POINTER*	topoLayer which holds the topodata
	* @param	$colscale		POINTER*	Pointer to the actual chromajs color scale
	* @param	$scale			void		defines the min-max-colorrange inside an array
	* @param	$domain			void		defines the min-max-inputrange inside an array
	* @result	$map			POINTER*	reference to leaflet widget
	**/
	
	var southWest 	= new L.latLng(52.5212+0.25+0.025, 13.4102-0.4), //y x
		northEast 	= new L.latLng(52.5212-0.25+0.025, 13.4102+0.4),
		bounds 		= new L.latLngBounds(southWest, northEast);
		
	var map = L.map('map',
					{maxZoom:12,minZoom:9,zoomControl:false,maxBounds:bounds},
					topoLayer = new L.TopoJSON()),
					colorScale = chroma 
					.scale(['#ffffcd','#c1e699','#78c67a','#30a355','#006837'])
					.domain([0,50]);
	map.setMaxBounds(bounds);
	map.fitBounds(bounds);
	
	// set the Coordinates and the Zoom level
	// in relation to the screen resolution

	var zoomFactor 	= 10;
	var panOffset	= 0.25;
	switch(window.screen.availWidth)
	{
		case 1920:
			zoomFactor 	= 11;
			panOffset	= 0.0;
			
			break;
		case 1280:
			zoomFactor = 10;
			panOffset	= 0.25;
			break;
	}
	
	map.setView([52.5212+panOffset, 13.4102], zoomFactor);				
	
	new L.Control.Zoom({ position: 'bottomright'}).addTo(map);
	
	L.tileLayer		(	'', 
					{ 	attribution:"&copy; Tommy Dräger 2016 | FenixFoxStudios", id:"milestails01.p909e3g1"}).addTo(map);

	// initialize the collision plugin
	var collisionLayer = L.LayerGroup.collision({margin:5});
	
	// paste the markers out of the marker.js manually one by one
	// markers is defined inside maker.js
	for (var i=0; i<markers.features.length; i++) 
	{
		var feat 			= markers.features[i];
		var labelClass 		= 'marker-label marker-label-' + feat.properties.scalerank;
				
		var marker = L.marker([feat.properties.lat, feat.properties.lng-0.005], 
		{
			clickable:false,
			interactive:true,
			icon: L.divIcon
			({
				html:	"<span class='" + labelClass + "'>" +
						feat.properties.name +
						"</span>"
			})
		});
		collisionLayer.addLayer(marker);
		
	}
	collisionLayer.addTo(map);

	// load topodata and pass it over to the addTopoData function
	$.getJSON('json/dbna-data.topo.json').done(addTopoData);

	/**
	* @func		addTopoData:	fills topoLayer with data, add to 'map' and call a func for each shape
	* @param	$topoData		topoJSON data	
	* @return	$void		
	**/
	function addTopoData(topoData)
	{  
		// 1) fills the data inside the topoLayer
		// 2) append the layer to the Leaflet-widget 'map'
		// 3) calls a function called 'handleLayer' for each element
		
		topoLayer.addData(topoData);
		topoLayer.addTo(map);
		topoLayer.eachLayer(handleLayer);  
	}	
	
	var propArray;			
	function recolorLayer(layer)
	{
	
		propArray = Array(	layer.feature.properties.gay1414,
							layer.feature.properties.gay1415,
							layer.feature.properties.gay1416,
							layer.feature.properties.gay1417,
							layer.feature.properties.gay1418,
							layer.feature.properties.gay1419,
							layer.feature.properties.gay1420,
							layer.feature.properties.gay1421,
							layer.feature.properties.gay1422,
							layer.feature.properties.gay1423,
							layer.feature.properties.gay1424,
							layer.feature.properties.gay1425,
							layer.feature.properties.gay1426,
							layer.feature.properties.gay1427,
							layer.feature.properties.gay1428);
							
		var color_value = propArray[ageSelector-14];
		
		fillColor = colorScale(color_value).hex();
		
		layer.setStyle
		({
			fillColor : fillColor,
		});
	}
							
	function handleLayer(layer)
	{  
		// create a popup with the "Name" property on it !! case sensetive	
		/*layer.bindPopup(	'Postleitzahl: ' + layer.feature.properties.plz + '<br />' + 
							'Ortsteil: ' + layer.feature.properties.quartier + '<br />' + 
							'Homosexuelle: ' + layer.feature.properties.gay1428 + '<br />');
		*/				
		propArray = Array(	layer.feature.properties.gay1414,
							layer.feature.properties.gay1415,
							layer.feature.properties.gay1416,
							layer.feature.properties.gay1417,
							layer.feature.properties.gay1418,
							layer.feature.properties.gay1419,
							layer.feature.properties.gay1420,
							layer.feature.properties.gay1421,
							layer.feature.properties.gay1422,
							layer.feature.properties.gay1423,
							layer.feature.properties.gay1424,
							layer.feature.properties.gay1425,
							layer.feature.properties.gay1426,
							layer.feature.properties.gay1427,
							layer.feature.properties.gay1428);
		
		// generate a randomValue
		// actually this should be
		// a certain demographic
		// property
		var color_value = propArray[ageSelector-14];
	
		// convert it into a hex
		// and pick the most similar
		// color value out of the colorScale
		fillColor = colorScale(color_value).hex();
		
		// set some self explanatory attributes
		layer.setStyle
		({
			fillColor : fillColor,
			fillOpacity: 0.65,
			color:'#005500',
			weight:0.5,
			opacity:0.9
		});
				
		layer.on
		({
    		mouseover: enterLayer,
	    	mouseout: leaveLayer
		});
	}		
	
	map.on('mousemove', function(e)
						{
							infoboxDiv.style.left = e.containerPoint.x + 25 + "px";
							infoboxDiv.style.top = e.containerPoint.y - 50 + "px";
						});

	var gays;
	function enterLayer(e) 
	{	
		gays = Array(	this.feature.properties.gay1414,
						this.feature.properties.gay1415,
						this.feature.properties.gay1416,
						this.feature.properties.gay1417,
						this.feature.properties.gay1418,
						this.feature.properties.gay1419,
						this.feature.properties.gay1420,
						this.feature.properties.gay1421,
						this.feature.properties.gay1422,
						this.feature.properties.gay1423,
						this.feature.properties.gay1424,
						this.feature.properties.gay1425,
						this.feature.properties.gay1426,
						this.feature.properties.gay1427,
						this.feature.properties.gay1428 );
	
		updateInfobox(	this.feature.properties.plz, 
						this.feature.properties.quartier, 
						this.feature.properties.bezirk, 
						gays[ageSelector-14]);
		
		var color_value = gays[ageSelector-14];
		fillColor = colorScale(color_value).hex();
						
		infoboxDiv.style.borderLeft = 'solid 5px ' + fillColor;
		infoboxDiv.style.display  = 'block';
		
		this.bringToFront();
		this.setStyle
		({
			fillOpacity: 0.65,
			color:'#ffffff',
			weight:2,
			opacity:0.9
		});		
		
	}
	
	function leaveLayer() 
	{	
		infoboxDiv.style.display = 'none';
		this.bringToBack();
		this.setStyle
		({
			fillOpacity: 0.65,
			color:'#005500',
			weight:0.5,
			opacity:0.9
		});
	}
	
	
	var legend = L.control({position: 'topright'});
	legend.onAdd = function(map) 
	{
		//this.bringToFront();
		var div 	= L.DomUtil.create('div', 'legend'),
			grades 	= ['#ffffcd','#c1e699','#78c67a','#30a355','#006837'],
			labels 	= ['0 - 10','10 - 20','25 - 30','30 - 50','über 50'];
				
			div.innerHTML = '<div class="legend-title">Dichte an Homosexuellen<br/>' + 
							'Im Alter von 14 bis 28</div><br>Berlin: 5513 Personen<br><br>';

		// loop through our density intervals and generate a label with a colored square for each interval
		for (var i = 0; i < grades.length; i++) 
		{
			div.innerHTML += 	'<table border="0">' + 
								'<tr><td><i style="background:' + 
								grades[i] + 
								'"></i></td><td class="legend-label">' + 
								labels[i] + 
								'</td></tr>' + 
								'</table>';
		}		
		return div;
	};
	legend.addTo(map);

	var ageSelector 	= 21;
	var settings 		= L.control({position: 'topleft'});
	var settingsDiv 	= L.DomUtil.create('div', 'settings');				
	settings.onAdd 		= function(map) 
	{
		settingsDiv.innerHTML = '<div class="settings-title">Gesuchte Altersspanne<br/>' + 
								'</div><br><span style="color:#999">Nach Welcher Altersspanne soll gefiltert werden?</span><br><br>' +
								'<span class="settings-title" style="color:#006837;font-size:15px">14 bis ' +
								ageSelector + ' Jahre</span>' +
								'<input type="range" name="ageSlider" min="14" max="28" oninput="updateSettings(this.value);" >';
		return settingsDiv ;
	};
	settings.addTo(map);

	function updateSettings(val) 
	{	
		ageSelector=val; 
		settingsDiv.getElementsByClassName("settings-title")[1].innerHTML = '14 bis ' + 
																			+ val + ' Jahre';

		topoLayer.eachLayer(recolorLayer);
    }	
	

	//use templates instead
	var plz			= "12459",
		township	= "Unter den Linden",
		region		= "Mitte",
		val			= "748";
	var infobox 	= L.control({position: 'topleft'});				
	var infoboxDiv 	= L.DomUtil.create('div', 'infobox');
	infobox.onAdd 	= function(map) 
	{
		infoboxDiv.innerHTML = '<div class="settings-title">' + 
								plz + 
								' ' + 
								township + 
								'<br/></div>' + 
								region + 
								'<br/><hr style="color: #ccc; background-color: #ccc; height: 0.75px; border:none"/>' + 
								'<span class="settings-title">' + 
								'<span class="settings-title" style="color:#000;font-weight:900;font-size:32px">' + 
								val + 
								'</span>' +
								' Personen</span>';
		return infoboxDiv ;
	};
	infobox.addTo(map);
	
	function updateInfobox(plz, township, region, val) 
	{	
		infoboxDiv.innerHTML = '<div class="settings-title">' + 
								plz + 
								' ' + 
								township + 
								'<br/></div>' + 
								region + 
								'<br/><hr style="color: #ccc; background-color: #ccc; height: 0.75px; border:none"/>' +
								'<span">' + 
								'<span style="color:#000;font-weight:700;font-size:25px">' + 
								val + 
								'</span>' +
								' Personen</span>';
    }
	
	

	// Disable dragging when user's cursor enters the element
	// Re-enable dragging when user's cursor leaves the element
	settings.getContainer().addEventListener('mouseover', 	function(){ map.dragging.disable(); });
	settings.getContainer().addEventListener('mouseout'	, 	function(){ map.dragging.enable(); });
	
	legend.getContainer().addEventListener('mouseover',		function(){ map.dragging.disable(); });
	legend.getContainer().addEventListener('mouseout'	, 	function(){ map.dragging.enable(); });

</script>

</div>  
</body>
</html>
